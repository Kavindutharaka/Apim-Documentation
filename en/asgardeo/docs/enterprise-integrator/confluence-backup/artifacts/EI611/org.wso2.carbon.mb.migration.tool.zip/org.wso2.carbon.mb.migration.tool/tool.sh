 #!/bin/bash

java -cp org.wso2.carbon.mb.migration.tool-2.0.jar:lib/* org.wso2.mb.migration.Main
